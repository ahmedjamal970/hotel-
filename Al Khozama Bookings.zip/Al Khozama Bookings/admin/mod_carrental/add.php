
<form class="form-horizontal well span6" action="controller.php?action=add" enctype="multipart/form-data" method="POST">

	<fieldset>
		<legend>New Car</legend>
											
          
        

          <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CAR">Name:</label>

              <div class="col-md-8">
              	<input name="" type="hidden" value="">
                 <input class="form-control input-sm" id="CAR" name="CAR" placeholder=
									  "Car Name" type="text" value="">
              </div>
            </div>
          </div>

            

 

            <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CARDESC">Description:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value="">
                 <input class="form-control input-sm" id="CARDESC" name="CARDESC" placeholder=
                    "Description" type="text" value="">
              </div>
            </div>
          </div>

         

        
 


           <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "RENT">Rent:</label>

              <div class="col-md-8"> 
                <input class="form-control input-sm" id="RENT" name="RENT" placeholder=
									  "Price" type="text" value="" onkeyup="javascript:checkNumber(this);">
              </div>
            </div>
          </div>

           <!--  <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CARMUM">No. of Rooms:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value=""> -->
                 <input class="form-control input-sm" id="CARNUM" name="CARNUM" placeholder=
                    "Car #" type="hidden" value="1">
           <!--    </div>
            </div>
          </div> -->
           
          <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "image">Upload Image:</label>

              <div class="col-md-8">
              <input type="file" name="image" value="" id="image">
              </div>
            </div>
          </div>

		
		 <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "idno"></label>

              <div class="col-md-8">
                <button class="btn btn-primary" name="save" type="submit" >Save</button>
              </div>
            </div>
          </div>

			
	</fieldset>	
	
</form>


</div><!--End of container-->
			
