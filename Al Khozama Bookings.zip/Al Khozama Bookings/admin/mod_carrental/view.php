 
<div class="panel panel-primary">
	<div class="panel-body">
		<table class="table table-hover" border="0">
			<caption><h3 align="left">Car Details</h3></caption>
		<tr>
		<td width="80"><img src="<?php echo $cur->carrentalImage; ?>" width="300" height="300" title="<?php echo $carName; ?>"/></td>
		<td align="left" align="left"><p><strong>Name </strong>
	 	<strong>Descrption </strong>
		<?php echo ': '.$cur->Desp; ?><br/>
		<strong>Price </strong>
		<?php echo ': '.$cur->rent; ?><br/>
	 
		<input type="button" value="&laquo Back" class="btn btn-primary" onclick="window.location.href='index.php'" >

	</p>
		
		
				</table>
	
	 </div><!--End of Panel Body-->
 </div><!--End of Main Panel-->  
