<?php 
require_once("../../includes/initialize.php");
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;

	case 'editimage' :
	editImg();
	break;
	
	case 'delete' :
	doDelete();
	break;


	}
function doInsert(){
	 
			
			if ($_POST['CAR'] == ""  ) {
			 
					message("All fields required!", "error");
					redirect("index.php?view=add");
				
			}else{
				$car = new car();

 

				$res = $car->find_all_car($_POST['CAR']);
				
				
				if ($res >=1) {
					message("car name already exist!", "error");
					redirect("index.php?view=add");
				}else{
				$location = '';
				if(isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])){
						$file=$_FILES['image']['tmp_name'];
						$image= $_FILES['image']['tmp_name'];
						$image_name= date('YmdHi').'_'.addslashes($_FILES['image']['name']);
						$image_size= getimagesize($_FILES['image']['tmp_name']);
						
						if ($image_size==FALSE) {
							message("That's not an image!");
							redirect("index.php?view=add");
					   }else{
						
							
							$location="cars/".$image_name;
							move_uploaded_file($image,"cars/".$image_name);
						}
				}
					 
				 $car->CAR 		=	$_POST['CAR'];
				$car->CARDESC 	=	$_POST['CARDESC'];
			 	$car->RENT 		=	$_POST['RENT'];
			 	$car->CARNUM    =   $_POST['CARNUM'];
			 	$car->OCARNUM 	=	$_POST['CARNUM'];
 				$car->CARIMAGE    = $location;
 			 		
					 $istrue = $car->create(); 
					 if ($istrue == 1){
					 	message("New [". $_POST['CAR'] ."] created successfully!", "success");
					 	redirect('index.php');
					 	
					 }
				}	 

		 
	}
  }
// }
//function to modify cars

 function doEdit(){


           		$car = new car();
           		$location = '';
				if(isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])){
					$file=$_FILES['image']['tmp_name'];
					$image= $_FILES['image']['tmp_name'];
					$image_name= date('YmdHi').'_'.addslashes($_FILES['image']['name']);
					$image_size= getimagesize($_FILES['image']['tmp_name']);
					
					if ($image_size==FALSE) {
						message("That's not an image!");
						redirect("index.php?view=edit");
				   }else{
					
						
						$location="cars/".$image_name;
						$move = move_uploaded_file($image,"cars/".$image_name);
					}
					}
				 $car->CAR 		=	$_POST['CAR'];
				$car->CARDESC 	=	$_POST['CARDESC'];
			 	$car->RENT 		=	$_POST['RENT'];
			    $car->CARNUM 		=	$_POST['CARNUM'];
			 	$car->OCARNUM 	=	$_POST['CARNUM'];
 				 if(!empty($location))
 				$car->CARIMAGE    = $location;
				
				$car->update($_POST['CARID']); 
				
			 	message($_POST['car'] ." Upadated successfully!", "success");
			 	unset($_SESSION['id']);
			 	redirect('index.php');
				 
}

function doDelete(){
@$id=$_POST['selector'];
		  $key = count($id);
		//multi delete using checkbox as a selector
		
	for($i=0;$i<$key;$i++){
	 
		$rm = new car();
		$rm->delete($id[$i]);
	}

		message("car already Deleted!","info");
		redirect('index.php');
 }
 
 //function to modify picture
 
function editImg (){
		if (!isset($_FILES['image']['tmp_name'])) {
			message("No Image Selected!", "error");
			redirect("index.php?view=list");
		}else{
			$file=$_FILES['image']['tmp_name'];
			$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$image_name= addslashes($_FILES['image']['name']);
			$image_size= getimagesize($_FILES['image']['tmp_name']);
			
			if ($image_size==FALSE) {
				message("That's not an image!");
				redirect("index.php?view=list");
		   }else{
			
		
				$location="cars/".$_FILES["image"]["name"];
				

	 				$rm = new car();
	          		$rm_id		= $_POST['id'];
				
			    	move_uploaded_file($_FILES["image"]["tmp_name"],"cars/".$_FILES["image"]["name"]);
					
					$rm->carIMAGE = $location;
					$rm->update($rm_id); 
					
				 	message("Car Image Upadated successfully!", "success");
				 	unset($_SESSION['id']);
				 	 redirect("index.php");
 			}
 		}
 }			 

function _deleteImage($catId)
{
    // we will return the status
    // whether the image deleted successfully
    $deleted = false;

	// get the image(s)
    $sql = "SELECT * 
            FROM car
            WHERE carNo ";
	
	if (is_array($catId)) {
		$sql .= " IN (" . implode(',', $catId) . ")";
	} else {
		$sql .= " = {$catId}";
	}	

    $result = dbQuery($sql);
    
    if (dbNumRows($result)) {
        while ($row = dbFetchAssoc($result)) {
		extract($row);
	        // delete the image file
    	    $deleted = @unlink($carImage);
		}	
    }
    
return $deleted;
}



?>
