
<?php

// $_SESSION['id']=$_GET['id'];
$rm = new Car();
$result = $rm->single_CAR($_GET['id']);
?>
<form class="form-horizontal well span6" action="controller.php?action=edit" enctype="multipart/form-data" method="POST">

	<fieldset>
		<legend>Edit Car</legend>
      
 
          <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CAR">Name:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value="">
                 <input name="CARID" type="hidden" value="<?php echo $result->CARID; ?>">
                 <input class="form-control input-sm" id="CAR" name="CAR" placeholder=
                    "CAR Name" type="text" value="<?php echo $result->CAR; ?>">
              </div>
            </div>
          </div>

         


 


           

          <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CARDESC">Description:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value="">
                 <input class="form-control input-sm" id="CARDESC" name="CARDESC" placeholder=
                    "Description" type="text" value="<?php echo $result->CARDESC; ?>">
              </div>
            </div>
          </div>

       


           <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "RENT">RENT:</label>

              <div class="col-md-8"> 
                <input class="form-control input-sm" id="RENT" name="RENT" placeholder=
                    "Price" type="text" value="<?php echo $result->RENT; ?>" onkeyup="javascript:checkNumber(this);">
              </div>
            </div>
          </div>

        
          <!--   <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "CARNUM">No. of Rooms:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value=""> -->
                 <input class="form-control input-sm" id="CARNUM" name="CARNUM" placeholder=
                    "Car #" type="hidden" value="<?php echo $result->CARNUM; ?>">
           <!--    </div>
            </div>
          </div>
         -->
         <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "image">Upload Image:</label>

              <div class="col-md-8">
              <input type="file" name="image" value="" id="image">
              </div>
            </div>
          </div>
          <div class="form-group">
            <img src="<?php echo isset($result->CARIMAGE) && !empty($result->CARIMAGE) && is_file($result->CARIMAGE) ? $result->CARIMAGE : '' ?>" alt="CAR Image" class="img-thumbnail col-md-5 col-md-offset-3" style=>
          </div>
	
		      <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "idno"></label>

              <div class="col-md-8">
                <button class="btn btn-primary" name="save" type="submit" >Save</button>
              </div>
            </div>
          </div>

			
	</fieldset>	
	
</form>


</div><!--End of container-->
			
