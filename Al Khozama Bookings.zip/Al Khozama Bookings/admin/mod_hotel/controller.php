<?php 
require_once("../../includes/initialize.php");
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	case 'add' :
	doInsert();
	break;
	
	case 'edit' :
	doEdit();
	break;

	case 'editimage' :
	editImg();
	break;
	
	case 'delete' :
	doDelete();
	break;


	}
function doInsert(){
	 
			
			if ($_POST['HOTEL'] == ""  ) {
			 
					message("All fields required!", "error");
					redirect("index.php?view=add");
				
			}else{
				$hotel = new Hotel();

 

				$res = $hotel->find_all_hotel($_POST['HOTEL']);
				
				
				if ($res >=1) {
					message("Hotel name already exist!", "error");
					redirect("index.php?view=add");
				}else{
				$location = '';
				if(isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])){
						$file=$_FILES['image']['tmp_name'];
						$image= $_FILES['image']['tmp_name'];
						$image_name= date('YmdHi').'_'.addslashes($_FILES['image']['name']);
						$image_size= getimagesize($_FILES['image']['tmp_name']);
						
						if ($image_size==FALSE) {
							message("That's not an image!");
							redirect("index.php?view=add");
					   }else{
						
							
							$location="hotels/".$image_name;
							move_uploaded_file($image,"hotels/".$image_name);
						}
				}
					 
				 $hotel->HOTEL 		=	$_POST['HOTEL'];
			    	$hotel->HOTELIMAGE    = $location;
 			 		
					 $istrue = $hotel->create(); 
					 if ($istrue == 1){
					 	message("New [". $_POST['HOTEL'] ."] created successfully!", "success");
					 	redirect('index.php');
					 	
					 }
				}	 

		 
	}
  }
// }
//function to modify hotels

 function doEdit(){


           		$hotel = new Hotel();
           		$location = '';
				if(isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])){
					$file=$_FILES['image']['tmp_name'];
					$image= $_FILES['image']['tmp_name'];
					$image_name= date('YmdHi').'_'.addslashes($_FILES['image']['name']);
					$image_size= getimagesize($_FILES['image']['tmp_name']);
					
					if ($image_size==FALSE) {
						message("That's not an image!");
						redirect("index.php?view=edit");
				   }else{
					
						
						$location="hotels/".$image_name;
						$move = move_uploaded_file($image,"hotels/".$image_name);
					}
					}
			 	$hotel->HOTEL 		=	$_POST['HOTEL'];
			 	if(!empty($location))
 				$hotel->HOTELIMAGE    = $location;
				
				$hotel->update($_POST['HOTELID']); 
				
			 	message($_POST['HOTEL'] ." Upadated successfully!", "success");
			 	unset($_SESSION['id']);
			 	redirect('index.php');
				 
}

function doDelete(){
@$id=$_POST['selector'];
		  $key = count($id);
		//multi delete using checkbox as a selector
		
	for($i=0;$i<$key;$i++){
	 
		$rm = new Hotel();
		$rm->delete($id[$i]);
	}

		message("Hotel already Deleted!","info");
		redirect('index.php');
 }
 
 //function to modify picture
 
function editImg (){
		if (!isset($_FILES['image']['tmp_name'])) {
			message("No Image Selected!", "error");
			redirect("index.php?view=list");
		}else{
			$file=$_FILES['image']['tmp_name'];
			$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
			$image_name= addslashes($_FILES['image']['name']);
			$image_size= getimagesize($_FILES['image']['tmp_name']);
			
			if ($image_size==FALSE) {
				message("That's not an image!");
				redirect("index.php?view=list");
		   }else{
			
		
				$location="hotels/".$_FILES["image"]["name"];
				

	 				$rm = new Hotel();
	          		$rm_id		= $_POST['id'];
				
			    	move_uploaded_file($_FILES["image"]["tmp_name"],"hotels/".$_FILES["image"]["name"]);
					
					$rm->HOTELIMAGE = $location;
					$rm->update($rm_id); 
					
				 	message("Hotel Image Upadated successfully!", "success");
				 	unset($_SESSION['id']);
				 	 redirect("index.php");
 			}
 		}
 }			 

function _deleteImage($catId)
{
    // we will return the status
    // whether the image deleted successfully
    $deleted = false;

	// get the image(s)
    $sql = "SELECT * 
            FROM hotel
            WHERE hotelNo ";
	
	if (is_array($catId)) {
		$sql .= " IN (" . implode(',', $catId) . ")";
	} else {
		$sql .= " = {$catId}";
	}	

    $result = dbQuery($sql);
    
    if (dbNumRows($result)) {
        while ($row = dbFetchAssoc($result)) {
		extract($row);
	        // delete the image file
    	    $deleted = @unlink($hotelImage);
		}	
    }
    
return $deleted;
}



?>
