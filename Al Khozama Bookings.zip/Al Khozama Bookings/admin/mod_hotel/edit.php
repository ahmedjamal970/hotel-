
<?php

// $_SESSION['id']=$_GET['id'];
$rm = new Hotel();
$result = $rm->single_hotel($_GET['id']);
?>
<form class="form-horizontal well span6" action="controller.php?action=edit" enctype="multipart/form-data" method="POST">

	<fieldset>
		<legend>Edit hotel</legend>
      
 
          <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "HOTEL">Name:</label>

              <div class="col-md-8">
                <input name="" type="hidden" value="">
                 <input name="HOTELID" type="hidden" value="<?php echo $result->HOTELID; ?>">
                 <input class="form-control input-sm" id="HOTEL" name="HOTEL" placeholder=
                    "HOTEL Name" type="text" value="<?php echo $result->HOTEL; ?>">
              </div>
            </div>
          </div>

        
 
         <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "image">Upload Image:</label>

              <div class="col-md-8">
              <input type="file" name="image" value="" id="image">
              </div>
            </div>
          </div>
          <div class="form-group">
            <img src="<?php echo isset($result->HOTELIMAGE) && !empty($result->HOTELIMAGE) && is_file($result->HOTELIMAGE) ? $result->HOTELIMAGE : '' ?>" alt="HOTEL Image" class="img-thumbnail col-md-5 col-md-offset-3" style=>
          </div>
	
		      <div class="form-group">
            <div class="col-md-8">
              <label class="col-md-4 control-label" for=
              "idno"></label>

              <div class="col-md-8">
                <button class="btn btn-primary" name="save" type="submit" >Save</button>
              </div>
            </div>
          </div>

			
	</fieldset>	
	
</form>


</div><!--End of container-->
			
