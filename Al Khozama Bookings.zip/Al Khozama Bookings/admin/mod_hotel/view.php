
 
<div class="panel panel-primary">
	<div class="panel-body">
		<table class="table table-hover" border="0">
			<caption><h3 align="left">Hotel Details</h3></caption>
		<tr>
		<td width="80"><img src="<?php echo $cur->hotelImage; ?>" width="300" height="300" title="<?php echo $hotelName; ?>"/></td>
		<td align="left" align="left"><p><strong>Name </strong>
		<?php echo ': '.$cur->typename; ?><br/>
		 <input type="button" value="&laquo Back" class="btn btn-primary" onclick="window.location.href='index.php'" >

	</p>
		
		
				</table>
	
	 </div><!--End of Panel Body-->
 </div><!--End of Main Panel-->  
